﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GM.Utilities
{
    /// <summary>
    /// 消息类型
    /// </summary>
    public enum EnumMsgType
    {
        IES = 1,
        LIVE = 2
    }
}
