﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GM.Utilities
{
    public class Tag
    {
        public EnumMsgType MsgType { get; set; }
        public string Version { get; set; }
    }
}
