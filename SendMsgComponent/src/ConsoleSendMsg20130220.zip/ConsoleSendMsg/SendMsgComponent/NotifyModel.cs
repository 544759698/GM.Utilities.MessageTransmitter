﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GM.Utilities
{
    class NotifyModel
    {
        public NotifyContext ModelContext { get; set; }

        public ReceiveProcessor.NotifyHandler ModelHandler { get; set; }

    }
}
