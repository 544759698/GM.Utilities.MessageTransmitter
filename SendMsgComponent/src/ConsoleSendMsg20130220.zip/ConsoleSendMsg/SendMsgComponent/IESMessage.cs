﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GM.Utilities
{
    public class IESMessage : IMessage
    {
        public Tag MsgTag { get; set; }
        public string ID { get; set; }
        public string DeviceID { get; set; }
        public IESMessage()
        {
            MsgTag = new Tag();
            this.MsgTag.MsgType = EnumMsgType.IES;
            this.MsgTag.Version = "1.0";
        }
    }
}
