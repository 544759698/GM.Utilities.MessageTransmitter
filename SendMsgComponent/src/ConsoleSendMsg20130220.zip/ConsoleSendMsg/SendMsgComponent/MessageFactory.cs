﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Net;
using System.Reflection;
using System.Text;

namespace GM.Utilities
{
    public class MessageFactory
    {
        /// <summary>
        /// 序列化
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        public static byte[] Serialize(IMessage message)
        {
            string package = string.Empty;
            try
            {
                string msgBody = string.Empty;
                switch (message.MsgTag.MsgType)
                {
                    case EnumMsgType.IES:
                        var iesmsg = (IESMessage)message;
                        msgBody = string.Format("{0}|{1}", iesmsg.ID, iesmsg.DeviceID);
                        break;
                    case EnumMsgType.LIVE:
                        var livemsg = (LIVEMessage)message;
                        msgBody = string.Format("{0}", livemsg.MsgBody);
                        break;
                    default:
                        throw new ApplicationException("消息类型错误");
                        break;
                }
                //为UDP包增加报头, 以便接收方业务处理
                package = string.Format("type={0},version={1},body={2}", (int)message.MsgTag.MsgType, message.MsgTag.Version, msgBody);

                Logger.WriteInfoFmt(Log.Serialize, "消息内容：{0}", new object[] { package });
            }
            catch (Exception ex)
            {
                Logger.WriteError(Log.Serialize, "消息序列化时出现异常", ex);
            }
            return Encoding.Default.GetBytes(package);
        }

        /// <summary>
        /// 反序列化
        /// </summary>
        /// <param name="iep"></param>
        /// <param name="content"></param>
        /// <returns></returns>
        public static NotifyContext Deserialize(IPEndPoint iep, string content)
        {
            var notify = new NotifyContext
            {
                MsgSender = new SenderInfo { Ip = iep.Address.ToString(), Port = iep.Port, SendTime = DateTime.Now }
            };

            try
            {
                string[] contentArr = content.Split(new[] { ',' });
                if (contentArr.Length < 3)
                {
                    throw new ApplicationException("消息解析长度小于3，消息内容：" + content);
                }
                EnumMsgType msgType = (EnumMsgType)Convert.ToInt32(contentArr[0].Substring(contentArr[0].IndexOf('=') + 1));
                string msgtag = contentArr[contentArr.Length - 1].Substring(contentArr[0].IndexOf('=') + 1);
                string[] propArr = msgtag.Split(new[] { '|' });
                switch (msgType)
                {
                    case EnumMsgType.IES:
                        var iesmsg = new IESMessage { MsgTag = { MsgType = msgType, Version = contentArr[1] }, ID = propArr[0], DeviceID = propArr[1] };
                        notify.Msg = iesmsg;
                        break;
                    case EnumMsgType.LIVE:
                        var livemsg = new LIVEMessage { MsgTag = { MsgType = msgType, Version = contentArr[1] }, MsgBody = propArr[0] };
                        notify.Msg = livemsg;
                        break;
                    default:
                        throw new ApplicationException("消息类型错误");
                        break;
                }
                Logger.WriteInfoFmt(Log.Deserialize, "消息类型：{0}，消息内容：{1}", new object[] { msgType.ToString(), content });
            }
            catch (Exception ex)
            {
                Logger.WriteError(Log.Deserialize, "消息反序列化时出现异常", ex);
            }
            return notify;
        }

        /// <summary>
        /// 获取消息发送器实例
        /// </summary>
        /// <returns></returns>
        public static IMessageProcessor GetInstance()
        {
            return new MessageProcessor();
        }
    }
}
