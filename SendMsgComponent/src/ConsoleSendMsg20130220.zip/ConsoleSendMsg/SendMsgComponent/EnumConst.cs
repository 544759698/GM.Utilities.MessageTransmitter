﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GM.Utilities
{
    public enum EnumMsgType
    {
        IES = 1,
        LIVE = 2
    }
}
