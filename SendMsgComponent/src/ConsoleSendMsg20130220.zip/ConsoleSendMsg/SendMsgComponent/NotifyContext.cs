﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GM.Utilities
{
    public class NotifyContext
    {
        public IMessage Msg { get; set; }
        public SenderInfo MsgSender { get; set; }
    }
}
