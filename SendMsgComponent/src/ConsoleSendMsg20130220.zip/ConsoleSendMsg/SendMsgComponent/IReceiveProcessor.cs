﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GM.Utilities
{
    public interface IReceiveProcessor
    {
        void Register(ReceiveProcessor.NotifyHandler handler, EnumMsgType msgType);
        void Start(string ip, int port);
        void Stop();
    }
}
